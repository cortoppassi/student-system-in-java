import Principal.Alunos;
import java.util.Scanner;
import java.util.ArrayList;

public class Principal {

    private static Scanner sc = new Scanner(System.in);
    private static ArrayList<Alunos> alunos = new ArrayList<>();

    public static void main(String[] args) {
        
        alunosPredefinidos();

        int menu = 0;
        do {
            System.out.println("Menu de opções");
            System.out.println("1 - Criar Alunos");
            System.out.println("2 - Editar Alunos");
            System.out.println("3 - Excluir Alunos");
            System.out.println("4 - Listar Alunos");
            System.out.println("5 - Buscar Aluno");
            System.out.print("Escolha uma dessas opções: ");

            menu = sc.nextInt();
            sc.nextLine();
            switch (menu) {
                case 1:
                    criarAlunos();
                    break;

                case 2:
                    editarAlunos();
                    break;

                case 3:
                    excluirAlunos();
                    break;

                case 4:
                    listarAlunos();
                    break;

                case 5:
                    buscarAlunos();
                    break;

                default:
                    System.out.println("Opção inválida");

            }

        } while (menu != 5);

    }

    private static void criarAlunos() {
        System.out.println("Digite o nome do Aluno: ");
        String nome = sc.nextLine();
        System.out.println("Digite a idade do Aluno: ");
        String idade = sc.nextLine();
        System.out.println("Digite o curso do Aluno: ");
        String curso = sc.nextLine();
        System.out.println("Digite o semestre do Aluno: ");
        String semestre = sc.nextLine();
        System.out.println("Digite a matrícula do Aluno: ");
        String matricula = sc.nextLine();

        Alunos aluno = new Alunos(nome, idade, curso, semestre, matricula);
        alunos.add(aluno);
    }

    private static void editarAlunos() {
        System.out.println("Digite a matrícula do Aluno que deseja editar: ");
        String matricula = sc.nextLine();

        for (int i = 0; i < alunos.size(); i++) {
            Alunos aluno = alunos.get(i);
            if (aluno.getMatricula().equals(matricula)) {
                System.out.println("Digite o novo nome do Aluno: ");
                String novoNome = sc.nextLine();
                System.out.println("Digite a nova idade do Aluno: ");
                String novaIdade = sc.nextLine();
                System.out.println("Digite o novo curso do Aluno: ");
                String novoCurso = sc.nextLine();
                System.out.println("Digite o novo semestre do Aluno: ");
                String novoSemestre = sc.nextLine();

                aluno.setNome(novoNome);
                aluno.setIdade(novaIdade);
                aluno.setCurso(novoCurso);
                aluno.setSemestre(novoSemestre);

                System.out.println("Aluno editado com sucesso!");
            }
        }
    }

    private static void excluirAlunos() {
        System.out.println("Digite a matrícula do Aluno que deseja excluir: ");
        String matricula = sc.nextLine();

        for (int i = 0; i < alunos.size(); i++) {
            Alunos aluno = alunos.get(i);
            if (aluno.getMatricula().equals(matricula)) {
                alunos.remove(i);
                System.out.println("Aluno excluído com sucesso!");
                break;
                          }
        }
    }

 private static void listarAlunos() {
    if (alunos.isEmpty()) {
        System.out.println("Não há alunos cadastrados.");
    } else {
        System.out.println("\t\t\t-----Lista de Alunos-----");
        System.out.println("|Nome|\t\t|Idade|\t\t|Curso|\t\t|Semestre|\t|Matricula|");
        System.out.println("___________________________________________________________________________________");
        
        for (Alunos aluno : alunos) {
            System.out.println(aluno.getNome() + "\t\t" + aluno.getIdade() + "\t\t" + aluno.getCurso() + "\t\t" + aluno.getSemestre() + "\t\t" + aluno.getMatricula());
            System.out.println("___________________________________________________________________________________");
        }
    }
}

    private static void buscarAlunos() {
        System.out.println("Digite a matrícula do Aluno que deseja buscar: ");
        String matricula = sc.nextLine();

        for (Alunos aluno : alunos) {
            if (aluno.getMatricula().equals(matricula)) {
                System.out.println("Aluno encontrado:");
                System.out.println(aluno);
                break;
            }
        }
    }
    
     private static void alunosPredefinidos() {
        Alunos aluno1 = new Alunos("Joao", "20", "Engenharia", "3", "2021001");
        Alunos aluno2 = new Alunos("Maria", "22", "Administracao", "5", "2021002");
        Alunos aluno3 = new Alunos("Pedro", "21", "Medicina", "4", "2021003");
        Alunos aluno4 = new Alunos("Ana", "19", "Psicologia", "2", "2021004");
        Alunos aluno5 = new Alunos("Lucas", "23", "Direito", "\t6", "2021005");
        Alunos aluno6 = new Alunos("Mariana", "20", "Arquitetura", "3", "2021006");
        Alunos aluno7 = new Alunos("Gabriel", "22", "C. Computacao", "5", "2021007");

        alunos.add(aluno1);
        alunos.add(aluno2);
        alunos.add(aluno3);
        alunos.add(aluno4);
        alunos.add(aluno5);
        alunos.add(aluno6);
        alunos.add(aluno7);
    }
}
